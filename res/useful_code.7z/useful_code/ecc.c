﻿/*
  This program implements the ECIES public key encryption scheme based on the
  NIST B163 elliptic curve and the XTEA block cipher. The code was written
  as an accompaniment for an article published in phrack #63 and is released to
  the public domain.
*/

#define TEST

#include "include/xtea.h"
#include "include/ecci.h"

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#ifndef _WIN32
#include <netinet/in.h>
#else
#include <winsock2.h>
#endif

//#define CHARS2INT(ptr) ntohl(*(uint32_t*)(ptr))
//#define INT2CHARS(ptr, val) MACRO( *(uint32_t*)(ptr) = htonl(val) )

#define DEV_RANDOM "/dev/urandom"

#define FATAL(s) MACRO( perror(s); exit(255) )

/******************************************************************************/

   /* the following type will represent bit vectors of length (keys->degree+MARGIN) */

//#define _numwords(key) (((key)->degree) + MARGIN + 31) / 32)

typedef uint32_t bitstr_t[ECC_MAX_DEGREE];
//typedef uint32_t* bitstr_t;

     /* some basic bit-manipulation routines that act on these vectors follow */
#define bitstr_getbit(A, idx) ((A[(idx) / 32] >> ((idx) % 32)) & 1)
#define bitstr_setbit(A, idx) MACRO( A[(idx) / 32] |= 1 << ((idx) % 32) )
#define bitstr_clrbit(A, idx) MACRO( A[(idx) / 32] &= ~(1 << ((idx) % 32)) )

#define bitstr_clear(A) MACRO( memset(A, 0, sizeof(bitstr_t)) )
#define bitstr_copy(A, B) MACRO( memcpy(A, B, sizeof(bitstr_t)) )
#define bitstr_swap(A, B) MACRO( bitstr_t h; \
  bitstr_copy(h, A); bitstr_copy(A, B); bitstr_copy(B, h) )
#define bitstr_is_equal(A, B) (! memcmp(A, B, sizeof(bitstr_t)))

int bitstr_is_clear(struct ecc_keys* keys, const bitstr_t x)
{
	int i;
    for (i = 0; i < bin_curve[keys->curve].numwords && !*x++; i++) ;
    return i == bin_curve[keys->curve].numwords;
}

			      /* return the number of the highest one-bit + 1 */
int bitstr_sizeinbits(struct ecc_keys* keys, const bitstr_t x)
{
	int i;
	uint32_t mask;
    for (x += bin_curve[keys->curve].numwords, i = 32 * bin_curve[keys->curve].numwords; i > 0 && !*--x; i -= 32) ;
	if (i)
		for (mask = 1 << 31; !(*x & mask); mask >>= 1, i--) ;
	return i;
}

					      /* left-shift by 'count' digits */
void bitstr_lshift(struct ecc_keys* keys, bitstr_t A, const bitstr_t B, int count)
{
	int i, offs = 4 * (count / 32);
	memmove((void *)A + offs, B, sizeof(bitstr_t) - offs);
	memset(A, 0, offs);
	if (count %= 32) {
        for (i = bin_curve[keys->curve].numwords - 1; i > 0; i--)
			A[i] = (A[i] << count) | (A[i - 1] >> (32 - count));
		A[0] <<= count;
	}
}

					    /* (raw) import from a byte array */
void bitstr_import(struct ecc_keys* keys, bitstr_t x, const char *s)
{
	int i;
    for (x += bin_curve[keys->curve].numwords, i = 0; i < bin_curve[keys->curve].numwords; i++, s += 4)
		*--x = CHARS2INT(s);
}

					      /* (raw) export to a byte array */
void bitstr_export(struct ecc_keys* keys, char *s, const bitstr_t x)
{
	int i;
    for (x += bin_curve[keys->curve].numwords, i = 0; i < bin_curve[keys->curve].numwords; i++, s += 4)
		INT2CHARS(s, *--x);
}

				   /* export as hex string (null-terminated!) */
void bitstr_to_hex(struct ecc_keys* keys, char *s, const bitstr_t x)
{
	int i;
    for (x += bin_curve[keys->curve].numwords, i = 0; i < bin_curve[keys->curve].numwords; i++, s += 8)
		sprintf(s, "%08x", *--x);
}

						 /* import from a hex string */
int bitstr_parse(struct ecc_keys* keys, bitstr_t x, const char *s)
{
	int len;
	if ((s[len = strspn(s, "0123456789abcdefABCDEF")]) ||
        (len > bin_curve[keys->curve].numwords * 8))
		return -1;
	bitstr_clear(x);
	x += len / 8;
	if (len % 8) {
		sscanf(s, "%08x", x);
		*x >>= 32 - 4 * (len % 8);
		s += len % 8;
		len &= ~7;
	}
	for (; *s; s += 8)
		sscanf(s, "%08x", --x);
	return len;
}

/******************************************************************************/
typedef bitstr_t elem_t;	/* this type will represent field elements */

elem_t poly;			/* the reduction polynomial */

#define field_set1(A) MACRO( A[0] = 1; memset(A + 1, 0, sizeof(elem_t) - 4) )

int field_is1(struct ecc_keys* keys, const elem_t x)
{
	int i;
	if (*x++ != 1)
		return 0;
    for (i = 1; i < bin_curve[keys->curve].numwords && !*x++; i++) ;
    return i == bin_curve[keys->curve].numwords;
}

void field_add(struct ecc_keys* keys, elem_t z, const elem_t x, const elem_t y)
{				/* field addition */
	int i;
    for (i = 0; i < bin_curve[keys->curve].numwords; i++)
		*z++ = *x++ ^ *y++;
}

#define field_add1(A) MACRO( A[0] ^= 1 )

						      /* field multiplication */
void field_mult(struct ecc_keys* keys, elem_t z, const elem_t x, const elem_t y)
{
	elem_t b;
	int i, j;
	/* assert(z != y); */
	bitstr_copy(b, x);
	if (bitstr_getbit(y, 0))
		bitstr_copy(z, x);
	else
		bitstr_clear(z);
    for (i = 1; i < keys->degree; i++) {
        for (j = bin_curve[keys->curve].numwords - 1; j > 0; j--)
			b[j] = (b[j] << 1) | (b[j - 1] >> 31);
		b[0] <<= 1;
        if (bitstr_getbit(b, keys->degree))
            field_add(keys, b, b, poly);
		if (bitstr_getbit(y, i))
            field_add(keys, z, z, b);
	}
}

void field_invert(struct ecc_keys* keys, elem_t z, const elem_t x)
{				/* field inversion */
	elem_t u, v, g, h;
	int i;
	bitstr_copy(u, x);
	bitstr_copy(v, poly);
	bitstr_clear(g);
	field_set1(z);
    while (!field_is1(keys, u)) {
        i = bitstr_sizeinbits(keys, u) - bitstr_sizeinbits(keys, v);
		if (i < 0) {
			bitstr_swap(u, v);
			bitstr_swap(g, z);
			i = -i;
		}
        bitstr_lshift(keys, h, v, i);
        field_add(keys, u, u, h);
        bitstr_lshift(keys, h, g, i);
        field_add(keys, z, z, h);
	}
}

/******************************************************************************/

/* The following routines do the ECC arithmetic. Elliptic curve points
   are represented by pairs (x,y) of elem_t. It is assumed that curve
   coefficient 'a' is equal to 1 (this is the case for all NIST binary
   curves). Coefficient 'b' is given in 'coeff_b'.  '(base_x, base_y)'
   is a point that generates a large prime order group.             */
elem_t coeff_b, base_x, base_y;

#define point_is_zero(keys, x, y) (bitstr_is_clear(keys, x) && bitstr_is_clear(keys, y))
#define point_set_zero(x, y) MACRO( bitstr_clear(x); bitstr_clear(y) )
#define point_copy(x1, y1, x2, y2) MACRO( bitstr_copy(x1, x2); \
                                          bitstr_copy(y1, y2) )

			   /* check if y^2 + x*y = x^3 + *x^2 + coeff_b holds */
int is_point_on_curve(struct ecc_keys* keys, const elem_t x, const elem_t y)
{
	elem_t a, b;
    if (point_is_zero(keys, x, y))
		return 1;
    field_mult(keys, a, x, x);
    field_mult(keys, b, a, x);
    field_add(keys, a, a, b);
    field_add(keys, a, a, coeff_b);
    field_mult(keys, b, y, y);
    field_add(keys, a, a, b);
    field_mult(keys, b, x, y);
    return bitstr_is_equal(a, b);
}

void point_double(struct ecc_keys* keys, elem_t x, elem_t y)
{				/* double the point (x,y) */
    if (!bitstr_is_clear(keys, x)) {
		elem_t a;
        field_invert(keys, a, x);
        field_mult(keys, a, a, y);
        field_add(keys, a, a, x);
        field_mult(keys, y, x, x);
        field_mult(keys, x, a, a);
		field_add1(a);
        field_add(keys, x, x, a);
        field_mult(keys, a, a, x);
        field_add(keys, y, y, a);
	} else
		bitstr_clear(y);
}

		   /* add two points together (x1, y1) := (x1, y1) + (x2, y2) */
void point_add(struct ecc_keys* keys, elem_t x1, elem_t y1, const elem_t x2, const elem_t y2)
{
    if (!point_is_zero(keys, x2, y2)) {
        if (point_is_zero(keys, x1, y1))
            point_copy( x1, y1, x2, y2);
		else {
			if (bitstr_is_equal(x1, x2)) {
				if (bitstr_is_equal(y1, y2))
                    point_double(keys, x1, y1);
				else
                    point_set_zero (x1, y1);
			} else {
				elem_t a, b, c, d;
                field_add(keys, a, y1, y2);
                field_add(keys, b, x1, x2);
                field_invert(keys, c, b);
                field_mult(keys, c, c, a);
                field_mult(keys, d, c, c);
                field_add(keys, d, d, c);
                field_add(keys, d, d, b);
				field_add1(d);
                field_add(keys, x1, x1, d);
                field_mult(keys, a, x1, c);
                field_add(keys, a, a, d);
                field_add(keys, y1, y1, a);
				bitstr_copy(x1, d);
			}
		}
	}
}

/******************************************************************************/
typedef bitstr_t exp_t;

exp_t base_order;
			 /* point multiplication via double-and-add algorithm */
void point_mult(struct ecc_keys* keys, elem_t x, elem_t y, const exp_t exp)
{
	elem_t X, Y;
	int i;
    point_set_zero( X, Y);
    for (i = bitstr_sizeinbits(keys, exp) - 1; i >= 0; i--) {
        point_double(keys, X, Y);
		if (bitstr_getbit(exp, i))
            point_add(keys, X, Y, x, y);
	}
    point_copy( x, y, X, Y);
}

			       /* draw a random value 'exp' with 1 <= exp < n */
/*
void get_random_exponent(struct ecc_keys* keys, exp_t exp)
{
    char buf[4 * bin_curve[keys->curve].numwords];
	int fh, r, s;
	do {
		if ((fh = open(DEV_RANDOM, O_RDONLY)) < 0)
			FATAL(DEV_RANDOM);
        for (r = 0; r < 4 * bin_curve[keys->curve].numwords; r += s)
            if ((s = read(fh, buf + r, 4 * bin_curve[keys->curve].numwords - r)) <= 0)
				FATAL(DEV_RANDOM);
		if (close(fh) < 0)
			FATAL(DEV_RANDOM);
        bitstr_import(keys, exp, buf);
        for (r = bitstr_sizeinbits(keys, base_order) - 1; r < bin_curve[keys->curve].numwords * 32;
		     r++)
			bitstr_clrbit(exp, r);
    } while (bitstr_is_clear(keys, exp));
}
*/


void get_random_exponent(struct ecc_keys* keys, exp_t exp){
    char buf[4*bin_curve[keys->curve].numwords];
	int r;
//    if(jrand_buf(buf, 4*bin_curve[keys->curve].numwords) < 0)
//		FATAL(DEV_RANDOM);	
    bitstr_import(keys, exp, buf);
}

/******************************************************************************/

//void ECIES_generate_key_pair(enum nist_bin_curve curve)
//{				/* generate a public/private key pair */
//    char buf[8 * bin_curve[curve].numwords + 1], *bufptr =
//        buf + bin_curve[curve].numwords * 8 - (bin_curve[curve].degree + 3) / 4;
//	elem_t x, y;
//	exp_t k;
//    get_random_exponent(keys, k);
//    point_copy( x, y, base_x, base_y);
//    point_mult(keys, x, y, k);
//	printf("Here is your new public/private key pair:\n");
//    bitstr_to_hex(keys, buf, x);
//	printf("Public key (Px:Py): %s:", bufptr);
//    bitstr_to_hex(keys, buf, y);
//	printf("%s\n", bufptr);
//    bitstr_to_hex(keys, buf, k);
//	printf("Private key: %s\n", bufptr);
//}

struct bin_curve_parameters* ECIES_getparams(enum nist_bin_curve curve){
    return curve < ECIES_INV?&bin_curve[curve]:NULL;
}

struct ecc_keys *ECIES_generate_keys(enum nist_bin_curve curve)
{
    char buf[8 * bin_curve[curve].numwords + 1], *bufptr =
        buf + bin_curve[curve].numwords * 8 - (bin_curve[curve].degree + 3) / 4;
	elem_t x, y;
	exp_t k;
    struct ecc_keys *keys;
	int i;

    struct bin_curve_parameters* params = ECIES_getparams(curve);

    if(!params){
        return NULL;
    }

    keys = (struct ecc_keys *) malloc(sizeof(struct ecc_keys));

    if(!keys) return NULL;

    keys->curve = curve;
    keys->degree = bin_curve[curve].degree;

    bitstr_parse(keys, poly, params->poly);
    bitstr_parse(keys, coeff_b, params->coeff_b);
    bitstr_parse(keys, base_x, params->base_x);
    bitstr_parse(keys, base_y, params->base_y);
    bitstr_parse(keys, base_order, params->base_order);

    get_random_exponent(keys, k);
    point_copy( x, y, base_x, base_y);
    point_mult(keys, x, y, k);
//  printf("Here is your new public/private key pair:\n");
    bitstr_to_hex(keys, buf, x);	//printf("Public key (Px:Py): %s:", bufptr);
	for (i = 0; i < 41; i++)
		keys->px[i] = bufptr[i];
	keys->px[41] = '\0';
    bitstr_to_hex(keys, buf, y);	//printf("%s\n", bufptr);
	for (i = 0; i < 41; i++)
		keys->py[i] = bufptr[i];
	keys->py[41] = '\0';
    bitstr_to_hex(keys, buf, k);	//printf("Private key: %s\n", bufptr);
	for (i = 0; i < 41; i++)
		keys->priv[i] = bufptr[i];
	keys->priv[41] = '\0';

	return keys;
}

       /* check that a given elem_t-pair is a valid point on the curve != 'o' */
int ECIES_embedded_public_key_validation(struct ecc_keys* keys, const elem_t Px, const elem_t Py)
{
    return (bitstr_sizeinbits(keys, Px) > keys->degree)
        || (bitstr_sizeinbits(keys, Py) > keys->degree) || point_is_zero(keys, Px, Py)
        || !is_point_on_curve(keys, Px, Py) ? -1 : 1;
}

      /* same thing, but check also that (Px,Py) generates a group of order n */
int ECIES_public_key_validation(struct ecc_keys *keys)
{
	elem_t x, y;
    if ((bitstr_parse(keys, x, keys->px) < 0) || (bitstr_parse(keys, y, keys->py) < 0))
		return -1;
    if (ECIES_embedded_public_key_validation(keys, x, y) < 0)
		return -1;
    point_mult(keys, x, y, base_order);
    return point_is_zero(keys, x, y) ? 1 : -1;
}

void ECIES_kdf(struct ecc_keys* keys, char *k1, char *k2, const elem_t Zx,	/* a non-standard KDF */
	       const elem_t Rx, const elem_t Ry)
{
    int bufsize = (3 * (4 * bin_curve[keys->curve].numwords) + 1 + 15) & ~15;
	char buf[bufsize];
	memset(buf, 0, bufsize);
    bitstr_export(keys, buf, Zx);
    bitstr_export(keys, buf + 4 * bin_curve[keys->curve].numwords, Rx);
    bitstr_export(keys, buf + 8 * bin_curve[keys->curve].numwords, Ry);
    buf[12 * bin_curve[keys->curve].numwords] = 0;
	XTEA_davies_meyer(k1, buf, bufsize / 16);
    buf[12 * bin_curve[keys->curve].numwords] = 1;
	XTEA_davies_meyer(k1 + 8, buf, bufsize / 16);
    buf[12 * bin_curve[keys->curve].numwords] = 2;
	XTEA_davies_meyer(k2, buf, bufsize / 16);
    buf[12 * bin_curve[keys->curve].numwords] = 3;
	XTEA_davies_meyer(k2 + 8, buf, bufsize / 16);
}

		  /* ECIES encryption; the resulting cipher text message will be
             (len + DEF_OVERHEAD) bytes long */
void ECIES_encrypt(struct ecc_keys* keys, char *msg, const char *text, int len)
{
    elem_t Rx, Ry, Zx, Zy;
	char k1[16], k2[16];
	exp_t k;

    bitstr_parse(keys, poly, bin_curve[keys->curve].poly);
    bitstr_parse(keys, coeff_b, bin_curve[keys->curve].coeff_b);
    bitstr_parse(keys, base_x, bin_curve[keys->curve].base_x);
    bitstr_parse(keys, base_y, bin_curve[keys->curve].base_y);
    bitstr_parse(keys, base_order, bin_curve[keys->curve].base_order);

	do {
        get_random_exponent(keys, k);
        bitstr_parse(keys, Zx, keys->px);
        bitstr_parse(keys, Zy, keys->py);
        point_mult(keys, Zx, Zy, k);
        point_double(keys, Zx, Zy);	/* cofactor h = 2 on B163 */
    } while (point_is_zero(keys, Zx, Zy));
    point_copy( Rx, Ry, base_x, base_y);
    point_mult(keys, Rx, Ry, k);
	ECIES_kdf(keys, k1, k2, Zx, Rx, Ry);

    bitstr_export(keys, msg, Rx);
    bitstr_export(keys, msg + 4 * bin_curve[keys->curve].numwords, Ry);
    memcpy(msg + 8 * bin_curve[keys->curve].numwords, text, len);
    XTEA_ctr_crypt(msg + 8 * bin_curve[keys->curve].numwords, len, k1);
    XTEA_cbcmac(msg + 8 * bin_curve[keys->curve].numwords + len, msg + 8 * bin_curve[keys->curve].numwords, len, k2);
}

							  /* ECIES decryption */
int ECIES_decrypt(struct ecc_keys* keys, char *text, const char *msg, int len)
{
	elem_t Rx, Ry, Zx, Zy;
	char k1[16], k2[16], mac[8];
	exp_t d;
    bitstr_import(keys, Rx, msg);
    bitstr_import(keys, Ry, msg + 4 * bin_curve[keys->curve].numwords);
    if (ECIES_embedded_public_key_validation(keys, Rx, Ry) < 0)
		return -1;
    bitstr_parse(keys, d, keys->priv);
    point_copy( Zx, Zy, Rx, Ry);
    point_mult(keys, Zx, Zy, d);
    point_double(keys, Zx, Zy);	/* cofactor h = 2 on B163 */
    if (point_is_zero(keys, Zx, Zy))
		return -2;
    ECIES_kdf(keys, k1, k2, Zx, Rx, Ry);

    XTEA_cbcmac(mac, msg + 8 * bin_curve[keys->curve].numwords, len, k2);
    if (memcmp(mac, msg + 8 * bin_curve[keys->curve].numwords + len, 8))
		return -3;
    memcpy(text, msg + 8 * bin_curve[keys->curve].numwords, len);
	XTEA_ctr_crypt(text, len, k1);
	return 1;
}

#undef TEST

/******************************************************************************/

#ifdef TEST

void encryption_decryption_demo(const char *text)
{
	int len = strlen(text) + 1;
    char *encrypted = malloc(len + bin_curve[ECIES_B163].overhead);
	char *decrypted = malloc(len);
	int ret;

    struct ecc_keys* keys = ECIES_generate_keys(ECIES_B163);
    if(!keys){
        FATAL("key gen failed!\n");
    }
    
    if(ECIES_public_key_validation(keys) < 0){
    	FATAL("key val failed!\n");
    } else {
    	printf("key ok!\n");
    }

    printf("KEYS\ndegree:%i\npx:%s\npy:%s\npv:%s\nKEYS\n", keys->degree, keys->px, keys->py,
           keys->priv);
           
	printf("NIST\ndegree:%i\nname:%s\npoly:%s\ncoeff:%s\nbase_x:%s\nbase_y:%s\nbase_order:%s\nnumwords:%i\noverhead:%i\nNIST\n",
	bin_curve[ECIES_B163].degree,
	bin_curve[ECIES_B163].name,
	bin_curve[ECIES_B163].poly,
	bin_curve[ECIES_B163].coeff_b,
	bin_curve[ECIES_B163].base_x,
	bin_curve[ECIES_B163].base_y,
	bin_curve[ECIES_B163].base_order,
	bin_curve[ECIES_B163].numwords,
	bin_curve[ECIES_B163].overhead);

	printf("plain text: %s\n", text);
    ECIES_encrypt(keys, encrypted, text, len);	/* encryption */
    
    free(keys);

	keys = ECIES_generate_keys(ECIES_B163);
	
    printf("KEYS\ndegree:%i\npx:%s\npy:%s\npv:%s\nKEYS\n", keys->degree, keys->px, keys->py,
           keys->priv);	

    if ((ret = ECIES_decrypt(keys, decrypted, encrypted, len)) < 0)	/* decryption */
		printf("decryption failed (%i)!\n", ret);
	else
		printf("after encryption/decryption: %s\n", decrypted);

	free(encrypted);
	free(decrypted);
    free(keys);
}

int main()
{
	encryption_decryption_demo("This secret demo message will be ECIES encrypted");

	return 0;
}

#endif				//TEST

/* f86c92039c992d2d2bd2b85c8807ac2f7af57c5c */
