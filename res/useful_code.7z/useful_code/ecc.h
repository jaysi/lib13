﻿#ifndef _ECC_H
#define _ECC_H

enum nist_bin_curve{
    ECIES_B163,
    ECIES_INV
};

struct ecc_keys {
    int degree;
    enum nist_bin_curve curve;
	char px[42];
	char py[42];
	char priv[42];    
};

//typedef struct _ecc_keys ecc_keys;

/*memmory allocation for encrypted message
  int len = strlen(text) + 1;
  char *encrypted = malloc(len + ECIES_OVERHEAD);
  char *decrypted = malloc(len);
*/
//extern int ECIES_overhead();

#ifdef __cplusplus
extern "C" {
#endif

struct ecc_keys *ECIES_generate_keys(enum nist_bin_curve curve);
int ECIES_public_key_validation(struct ecc_keys* key);
void ECIES_encrypt(struct ecc_keys* keys, char *msg, const char *text, int len);
int ECIES_decrypt(struct ecc_keys* keys, char *text, const char *msg, int len);

#ifdef __cplusplus
}
#endif

#endif
