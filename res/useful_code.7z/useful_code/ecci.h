﻿#ifndef ECCI_H
#define ECCI_H

#include "ecc.h"

//#define DEF_NAME    "B163"
//#define DEF_DEGREE  163	/* the degree of the field polynomial */
#define MARGIN  3		/* don't touch this */
//#define DEF_NUMWORDS ((DEF_DEGREE + MARGIN + 31) / 32)
//#define DEF_OVERHEAD (8 * DEF_NUMWORDS + 8)

#define ECC_MAX_DEGREE 571

struct bin_curve_parameters{
    int degree;
    char* name;
    char* poly;
    char* coeff_b;
    char* base_x;
    char* base_y;
    char* base_order;
    int numwords;
    int overhead;
} bin_curve[] = {
    {/*B163 parameters*/
        163,
        "B163",
        "800000000000000000000000000000000000000c9",
        "20a601907b8c953ca1481eb10512f78744a3205fd",
        "3f0eba16286a2d57ea0991168d4994637e8343e36",
        "0d51fbc6c71a0094fa2cdd545b11c5c0c797324f1",
        "40000000000000000000292fe77e70c12a4234c33",
        ((163+MARGIN+31)/32),
        (8*((163+MARGIN+31)/32) + 8)
    },
    {0, 0, 0, 0, 0, 0, 0}
};

#endif // ECCI_H
